import numpy as np
from requests import check_compatibility
from cards import Cards
from player import Player
numOfCards=13

class GameMaster:
    round = 0
    bids=[0,0,0,0]#stores bids according to the order static variable
    sequence = [0, 1, 2, 3]  # this is the sequence of players who throw card
    history = []
    order=[]
    lastRoundWinner = None #this is used as the previous winner in a set of 4 cards regardless of rounds
    playInfo = {
        "timeBudget": None,  # float
        "playerId": None,  # string
        # 4 strings
        "playerIds": [
            "P0",
            "P1",
            "P2",
            "P3"
        ],
        #  upto 13 cards in string format
        "cards": [],
        #  upto 3 cards in order from last winner
        #  last winner can be inferred from last item in history
        #  e.g > payload.history[payload.history.length - 1][2]
        "played": [],
        #  'history' field contains an ordered list of cards played from first hand.
        #  Format: 'start idx, [cards in clockwise order of player ids], winner idx'
        #  'start idx' is index of player that threw card first
        #  'winner idx' is index of player who won this hand
        "history": [],
        #  Context has metadata about the current round:
        #  'ruond': the current round[1 - 5]
        #  'totalPoints': the points accumulated till this round(dhoos is also subtracted)
        #  'bid': bid of current round
        #  'won': total hands won this round upto this point
        "context": {
            "round": 0,
            "players": {
                "P0": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                },
                "P1": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                },
                "P2": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                },
                "P3": {
                    "totalPoints": 0,
                    "bid":0,
                    "won":0
                }
            }
        }
    }
    bidInfo = {
        #    timeBudget left for this round, time alloted for bid + play 12 hands
        "timeBudget": None,
        #    current player's string; this is your id
        "playerId": None,
        #    4 strings
        "playerIds": ["P0", "P1", "P2", "P3"],
        #    13 cards in string format
        "cards": [],
        #    Context has metadata about the current round:
        #  'ruond': the current round [1 - 5]
        #  'totalPoints': the points accumulated till this round (dhoos is also subtracted)
        #  'bid': bid of current round
        #  'won': total hands won this round upto this point
        "context": {
            "round": 0,
            "players": {
                "P0": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                },
                "P1": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                },
                "P2": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                },
                "P3": {
                    "totalPoints": 0,
                    "bid": 0,
                    "won": 0
                }
            }
        }
    }

    @staticmethod
    def distribute():
        idx = np.random.permutation(52)
        allCards = Cards.createCombo()
        np.random.shuffle(allCards)
        p1 = [allCards[i] for i in idx[0:13]]
        p2 = [allCards[i] for i in idx[13:26]]
        p3 = [allCards[i] for i in idx[26:39]]
        p4 = [allCards[i] for i in idx[39:52]]
        return p1, p2, p3, p4
    
    @staticmethod
    def setupOrder():
        if GameMaster.lastRoundWinner==None:
            GameMaster.order=[0,1,2,3]
        else:
            GameMaster.order=[(GameMaster.order[GameMaster.lastRoundWinner]+a)%4 for a in range(4)]

    @staticmethod
    def biddingPhase(players):#order represents the order in which the bids are to be made
        # and cards are to be thrown
        GameMaster.setupOrder()
        for playerNum in GameMaster.order:
            GameMaster.updateBidInfo(players[playerNum])
            while True:
                print("Asking bid from player"+players[playerNum].playerName)
                bid=players[playerNum].giveBid(GameMaster.bidInfo)
                if bid>=1 and bid<=8:
                    break
                else:
                    print("{players[playerNum].playerName} input invalid bid!!!!")
            GameMaster.bidInfo["context"]["players"][players[playerNum].playerName]["bid"]=bid
            GameMaster.playInfo["context"]["players"][players[playerNum].playerName]["bid"]=bid
            GameMaster.bids[playerNum]=bid#this stores bid acc to the values in the variable order

    @staticmethod
    def updateBidInfo(player):
        GameMaster.bidInfo["playerId"]=player.playerName
        GameMaster.bidInfo["cards"]=player.cards
        GameMaster.bidInfo["context"]["round"]=GameMaster.round
    
    @staticmethod
    def oneRound(players):
        for i in range(numOfCards):
            if i!=0:
                GameMaster.setupOrder()
            for playerNum in GameMaster.order:
                GameMaster.updatePlayInfo(players[playerNum])
                cardResponse=players[playerNum].playCard(GameMaster.playInfo)#need to remove the used card here and add validation as well
                if not GameMaster.checkCompatibility(cardResponse):
                    raise("Invalid Move!!!!")
                GameMaster.playInfo["played"].append(cardResponse)
            
            GameMaster.lastRoundWinner=GameMaster.winCondition()
            
            #the last round winner will be the position of the card in the Gamemaster.playInfo["played"]
            #and the order list will also have to be used to determine the winner
            GameMaster.history.append([GameMaster.order[0],GameMaster.playInfo["played"],\
                                            GameMaster.order[GameMaster.lastRoundWinner]])
            GameMaster.playInfo["history"]=GameMaster.history
            GameMaster.playInfo["played"]=[]
            
            winPlayer=players[GameMaster.order[GameMaster.lastRoundWinner]]#winner player
            winPlayer.roundScores+=1
            GameMaster.playInfo["context"]["players"][winPlayer.playerName]["won"]+=1
            GameMaster.bidInfo["context"]["players"][winPlayer.playerName]["won"]+=1

    @staticmethod
    def updatePlayInfo(player):
        GameMaster.playInfo["playerId"]=player.playerName
        GameMaster.playInfo["cards"]=player.cards
        GameMaster.playInfo["context"]["round"]=GameMaster.round
    

    @staticmethod
    def winCondition():
        """THis could have been def winCondition(played) to check the working"""
        played=GameMaster.playInfo["played"]
        spades=[]
        firstSuit=[]
        for card in played:
            if card[1]=="S":
                spades.append(card)
            elif card[1]==played[0][1]:
                firstSuit.append(card)
        winner=0
        if len(spades)!=0:
            winner=spades[0]
            for card in spades[1:]:
                if Cards.getRank(card)["value"]>Cards.getRank(winner)["value"]:
                    winner=card
        elif len(firstSuit)>=1:
            winner = firstSuit[0]
            for card in firstSuit[1:]:
                if Cards.getRank(card)["value"]>Cards.getRank(winner)["value"]:
                    winner=card
        return played.index(winner)

      



    @staticmethod
    def scoreUpdate(players):
        for player in players:
            if player.roundScores==player.bid:
                player.scores[GameMaster.round-1]=player.roundScores
            elif player.roundScores>player.bid:
                player.scores[GameMaster.round-1]=player.bid+(player.roundScores-player.bid)/10
            else:
                player.scores[GameMaster.round-1]=-player.bid
            GameMaster.bidInfo["context"]["players"][player.playerName]["totalPoints"]+=player.scores[GameMaster.round-1]
            GameMaster.playInfo["context"]["players"][player.playerName]["totalPoints"]+=player.scores[GameMaster.round-1]



    @staticmethod
    def cleaningPerRound(players):
        #for cleaning after each round->bids and wons per round are cleaned, history is also cleared
        for player in players:
            player.roundScores=0
            player.bid=0
            GameMaster.bidInfo["context"]["players"][player.playerName]["bid"]=0
            GameMaster.bidInfo["context"]["players"][player.playerName]["won"]=0
            GameMaster.playInfo["context"]["players"][player.playerName]["bid"]=0
            GameMaster.playInfo["context"]["players"][player.playerName]["won"]=0
            GameMaster.playInfo["history"]=[]
            GameMaster.history=[]

    @staticmethod
    def checkCompatibility(response,played):#plyayed hatauna parcha ya
        # played=GameMaster.playInfo["played"]
        if not response in GameMaster.playInfo["cards"]:
            return False
        else:
            GameMaster.playInfo["cards"].remove(response)
        if len(played)==0:
            return True
        elif len(played)==1:#this checks the condition for only one player prior to us

            remaining=GameMaster.playInfo["cards"]#these are the remaining cards with the player after throwing the response
            firstCard=played[0]#first card played by the first player
            if Cards.getSuit(response)["code"]==Cards.getSuit(firstCard)["code"]:
                if Cards.getRank(response)["value"]>Cards.getRank(firstCard)["value"]:
                    return True
                else:
                    for card in remaining:
                        if Cards.getSuit(card)["code"]==Cards.getSuit(firstCard)["code"]:
                            if Cards.getRank(card)["value"]>Cards.getRank(firstCard)["value"]:
                                return False
                    return True
            else:
                for card in remaining:
                    if Cards.getSuit(card)["code"]==Cards.getSuit(firstCard)["code"]:
                        return False 
                if Cards.getSuit(response)["code"]!="S":
                    for card in remaining:
                        if Cards.getSuit(card)["code"]=="S":
                            return False
                return True
        elif len(played)==2:#this checks the condition for two players who have played before us
            remaining=GameMaster.playInfo["cards"]#these are the remaining cards with the player after throwing the response
            firstCard=played[0]#first card played by the first player
            secondCard=played[1]#second card played

            if firstCard[1]==secondCard[1]:
                if response[1]==firstCard[1]:
                    if Cards.getRank(response)["value"]>Cards.getRank(firstCard)["value"] and \
                       Cards.getRank(response)["value"]>Cards.getRank(secondCard)["value"]: 
                        return True
                    else:
                        for card in remaining:
                            if card[1]==response[1]:
                                if Cards.getRank(card)["value"]>Cards.getRank(firstCard)["value"] and \
                                    Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]: 
                                    return False
                        return True
                else:
                    if response[1]=="S":
                        for card in remaining:
                            if card[1]==secondCard[1]:
                                return False
                        return True
                    else:
                        for card in remaining:
                            if card[1]==secondCard[1] or card[1]=="S":
                                return False
                        return True
            else:
                if secondCard[1]=="S":
                    if response[1]==firstCard[1]:
                        return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        if Cards.getRank(response)["value"]>Cards.getRank(secondCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if card[1]=="S":
                                    if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                        return False
                            return True
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                            elif card[1]=="S":
                                if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                    return False
                        return True
                else:
                    if response[1]==firstCard[1]:
                        if Cards.getRank(response)["value"]>Cards.getRank(firstCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if Cards.getRank(card)["value"]>Cards.getRank(firstCard)["value"]:
                                    return False
                            return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        return True
                    else:
                        for card in remaining:
                            if card[1]=="S" or card[1]==firstCard[1]:
                                return False
                        return True
        elif len(played)==3:
            remaining=GameMaster.playInfo["cards"]#these are the remaining cards with the player after throwing the response
            firstCard=played[0]#first card played by the first player
            secondCard=played[1]#second card played
            thirdCard=played[2]#third card played
            if firstCard[1]==secondCard[1]:
                if secondCard[1]==thirdCard[1]:
                    if response[1]==firstCard[1]:
                        if Cards.getRank(response)["value"]>Cards.getRank(thirdCard)["value"] and\
                            Cards.getRank(response)["value"]>Cards.getRank(secondCard) and\
                                Cards.getRank(response)["value"]>Cards.getRank(firstCard):
                            
                            return True
                        else:
                            for card in remaining:
                                if card[1]==firstCard[1]:
                                    if Cards.getRank(card)["value"]>Cards.getRank(thirdCard)["value"] and\
                                        Cards.getRank(card)["value"]>Cards.getRank(secondCard) and\
                                        Cards.getRank(card)["value"]>Cards.getRank(firstCard):
                                        return False
                            return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        return True
                    else:
                        for card in remaining:
                            if card[1]=="S" or card[1]==firstCard[1]:
                                return False
                        return True
                elif thirdCard[1]=="S":
                    if response[1]==firstCard[1]:
                        return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        if Cards.getRank(response)["value"]>Cards.getRank(thirdCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if card[1]=="S":
                                    if Cards.getRank(card)["value"]>Cards.getRank(thirdCard)["value"]:
                                        return False
                            return True
                    else:
                        for card in remaining:
                            if card[1]=="S" or card[1]==firstCard[1]:
                                return False
                        return True
                else:
                    if response[1]==firstCard[1]:
                        if Cards.getRank(response)["value"]>Cards.getRank(firstCard)["value"] and\
                            Cards.getRank(response)["value"]>Cards.getRank(secondCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if Cards.getRank(card)["value"]>Cards.getRank(firstCard)["value"] and\
                                    Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                    return False
                            return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        return True
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1] or card[1]=="S":
                                return False
                        return True
            elif secondCard[1]=="S":
                if thirdCard[1]==firstCard[1]:
                    if response[1]==firstCard[1]:
                        return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        if Cards.getRank(response)["value"]>Cards.getRank(secondCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if card[1]=="S":
                                    if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                        return False
                            return True
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                            elif card[1]=="S":
                                if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                    return False
                        return True
                elif thirdCard[1]=="S":
                    if response[1]==firstCard[1]:
                        return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        if Cards.getRank(response)["value"]>Cards.getRank(thirdCard)["value"] and\
                            Cards.getRank(response)["value"]>Cards.getRank(secondCard)["value"]:
                            # print("greater than both")
                            return True
                        else:
                            for card in remaining:
                                if card[1]=="S":
                                    if Cards.getRank(card)["value"]>Cards.getRank(thirdCard)["value"] and\
                                        Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                        return False
                            return True 
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                            elif card[1]=="S":
                                if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]\
                                    and Cards.getRank(card)["value"]>Cards.getRank(thirdCard)["value"]:
                                    return False
                        return True
                else:
                    if response[1]==firstCard[1]:
                        return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        if Cards.getRank(response)["value"]>Cards.getRank(secondCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if card[1]=="S":
                                    if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                        return False
                            return True 
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                            elif card[1]=="S":
                                if Cards.getRank(card)["value"]>Cards.getRank(secondCard)["value"]:
                                    return False
                        return True
            else:
                if thirdCard[1]==firstCard[1]:
                    if response[1]==firstCard[1]:
                        if Cards.getRank(response)["value"]>Cards.getRank(firstCard)["value"] and\
                            Cards.getRank(response)["value"]>Cards.getRank(thirdCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if Cards.getRank(card)["value"]>Cards.getRank(firstCard)["value"] and\
                                    Cards.getRank(card)["value"]>Cards.getRank(thirdCard)["value"]:
                                    return False
                            return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        return True
                    else:
                        for card in remaining:
                            if card[1]=="S" or card[1]==firstCard[1]:
                                return False
                        return True
                elif thirdCard[1]=="S":
                    if response[1]==firstCard[1]:
                        return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        if Cards.getRank(response)["value"]>Cards.getRank(thirdCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if card[1]=="S":
                                    if Cards.getRank(response)["value"]>Cards.getRank(thirdCard)["value"]:
                                        return False
                            return True
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                            elif card[1]=="S":
                                if Cards.getRank(card)["value"]>Cards.getRank(thirdCard)["value"]:
                                    return False
                        return True
                else:
                    if response[1]==firstCard[1]:
                        if Cards.getRank(response)["value"]>Cards.getRank(firstCard)["value"]:
                            return True
                        else:
                            for card in remaining:
                                if Cards.getRank(card)["value"]>Cards.getRank(firstCard)["value"]:
                                    return False
                            return True
                    elif response[1]=="S":
                        for card in remaining:
                            if card[1]==firstCard[1]:
                                return False
                        return True
                    else:
                        for card in remaining:
                            if card[1]==firstCard[1] or card[1]=="S":
                                return False
                        return True


                        




