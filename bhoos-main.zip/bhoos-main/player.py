class Player:
    player_count=0
    def __init__(self):
        self.cards=0
        self.scores=[0]*5
        self.bid=0
        self.roundScores=0
        self.playerName="P"+str(Player.player_count)
        Player.player_count+=1
        self.club=[]
        self.spade=[]
        self.diamond=[]
        self.heart=[]

    def giveBid(self,bidContext):
        self.bid=3#this needs to be stored as well
        return 3 #this has to be setup later using RL

    def playCard(self,playContext):
        # print(playContext)
        # print("\n")
        card2play=""
        Player.suitCards(card2play[1]).remove(card2play)
        return self.cards.pop(self.card.index(card2play))#need to make ammends to update the individual lists as well


    def dealtCards(self,cards):
        """This is called at the beginning when we have to distribute the cards to players"""
        self.cards=cards
        for card in cards:
            if card[1]=="H":
                self.heart.append(card)
            elif card[1]=="S":
                self.spade.append(card)
            elif card[1]=="D":
                self.diamond.append(card)
            else:
                self.club.append(card)
    def suitCards(self,suit):
        if suit=="H":
            return self.heart
        if suit=="C":
            return self.club
        if suit=="D":
            return self.diamond
        else:
            return self.spade
        
