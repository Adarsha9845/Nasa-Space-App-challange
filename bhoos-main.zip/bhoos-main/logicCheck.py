from gameMaster import GameMaster

GameMaster.playInfo["played"]=[]
