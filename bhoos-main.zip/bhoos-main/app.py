from gameMaster import GameMaster

from player import Player
from cards import Cards

# print("Run26\n")
# players=[Player() for _ in range(4)]
# for a in range(2):
#     GameMaster.round+=1
    
#     for player, card in zip(players,GameMaster.distribute()):
#         player.dealtCards(card)
#     GameMaster.biddingPhase(players)
#     GameMaster.oneRound(players)
#     GameMaster.scoreUpdate(players)
#     GameMaster.cleaningPerRound(players)
#     print(GameMaster.order)

#     print(GameMaster.bidInfo)
#     print(GameMaster.playInfo)


# print("Win condition check:::")
# winner=GameMaster.winCondition(["2S","KS","4H","1S"])
# print(winner)

# cards=['TH', '3H', '9S', '1D', '2D', '6S', 'QD', '4D', 'QC', '7C', '1S', 'JD', '8C']
cards=['4H','9S', '1D', '2D', '6S', 'QD', '4D', 'QC', '7C', 'JD', '8C']
GameMaster.playInfo["cards"]=cards
print(GameMaster.playInfo["cards"])
print(GameMaster.checkCompatibility('4D',['5H','QS','6D']))
print(GameMaster.playInfo["cards"])